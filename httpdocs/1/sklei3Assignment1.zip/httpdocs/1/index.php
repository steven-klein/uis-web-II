<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Assignment 1</title>
        <style>
            .php {
                font-size: 2em;
                font-style: italic;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <main>
            <h1>PHP And HTML</h1>
            <p>
                Learning HTML is fun<br>
                Learning HTML is very easy
            </p>
            <p class="php">
                <?php echo "Learning PHP is fun";?><br>
                <?php echo "Learning PHP is very easy";?>
            </p>
        </main>
    </body>
</html>
